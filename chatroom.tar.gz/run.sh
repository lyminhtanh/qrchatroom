#!/bin/sh

SCRIPTPATH=$(cd "$(dirname "$0")"; pwd)
"$SCRIPTPATH/chatroom" -importPath chatroom -srcPath "$SCRIPTPATH/src" -runMode prod
